# Prova de avaliação SICREDI
Os testes automatizados apresentados servem para validar CEPs do Brasil, de acordo com o CEP informado para determinar se é válido, inexistente ou com formato inválido.

## Frameworks

Java 8 + Maven, JUnit e Framework Rest Assured.

## Versionamento

O Projeto está versionado no Git dentro do repositório **prova_sicredi_api** na branch **master**.

## Como rodar?

 1.  Descompacte o arquivo zipado **prova_sicredi_api.zip**;
 2.  Importe-o como Maven Project em sua IDE;
 3.  Abra a classe TesteCEP.java dentro do diretorio src/test/java localizada no pacote **br.com.sicredi.prova_sicredi_api**;
 4.  Execute a classe TesteCEP.java como JUnit Test.


