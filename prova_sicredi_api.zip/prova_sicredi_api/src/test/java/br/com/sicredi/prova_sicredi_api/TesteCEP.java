package br.com.sicredi.prova_sicredi_api;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;

import org.junit.Test;

public class TesteCEP {
	
	String url = "https://viacep.com.br/ws/";
	
	@Test
	public void consultaCEPExistente() {
		String cep = "91060900";
		given()
			.when()
				.get(url + cep + "/json/")
			.then()
				.statusCode(200)
				.body("cep", equalTo("91060-900"))
				.body("logradouro", equalTo("Avenida Assis Brasil 3940")) 
				.body("complemento", equalTo(""))
				.body("bairro", equalTo("São Sebastião"))
				.body("localidade", equalTo("Porto Alegre"))
				.body("uf", equalTo("RS"))
				.body("ibge", equalTo("4314902"));
	}			
	
	@Test
	public void consultaCEPInexistente() {
		String cep = "11111111";
		given()
			.when()
				.get(url + cep + "/json/")
			.then()
				.statusCode(200)
				.body("erro", is(Boolean.TRUE));		
	}
	
	@Test
	public void consultaCEPcomFormatoInvalido() {
		String cep = "1111111";
		given()
			.when()
				.get(url + cep + "/json/")
			.then()
				.statusCode(400);				
		
	}

	@Test
	public void verificaRetornoServico() {		
		given()
			.when()
				.get(url + "RS/Gravatai/Barroso" +"/json/")
			.then()
				.statusCode(200)
				.body("$", hasSize(2))
				.body("cep[0]", equalTo("94085-170") )
				.body("logradouro[0]", equalTo("Rua Ari Barroso") )
				.body("complemento[0]", equalTo("") )
				.body("bairro[0]", equalTo("Morada do Vale I") )
				.body("localidade[0]", equalTo("Gravataí") )
				.body("uf[0]", equalTo("RS") )
				.body("unidade[0]", equalTo("") )
				.body("ibge[0]", equalTo("4309209") )
				.body("gia[0]", equalTo("") )
				
				.body("cep[1]", equalTo("94175-000") )
				.body("logradouro[1]", equalTo("Rua Almirante Barroso") )
				.body("complemento[1]", equalTo("") )
				.body("bairro[1]", equalTo("Recanto Corcunda") )
				.body("localidade[1]", equalTo("Gravataí") )
				.body("uf[1]", equalTo("RS") )
				.body("unidade[1]", equalTo("") )
				.body("ibge[1]", equalTo("4309209") )
				.body("gia[1]", equalTo("") );
		
	} 
}